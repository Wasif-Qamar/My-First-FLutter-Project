package com.example.app_development_assignment_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
